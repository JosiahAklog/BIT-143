
public class UnsortedList<Type> extends AbstractList<Type> {

    private Node<Type> tail;

    @Override
    protected Node<Type> getHead() {
        return tail != null ? tail.next : null;
    }

    public UnsortedList() {
        super();
    }

    public void insert(Type value) {
        if (value == null) {
            throw new NullPointerException("Cannot insert null value");
        }
        Node<Type> newNode = new Node<>(value);
        if (isEmpty()) {
            tail = newNode;
            tail.next = tail;
        } else {
            newNode.next = tail.next;
            tail.next = newNode;
            tail = newNode;
        }
        size++;
    }

    public Type remove(Type value) {
        if (value == null) {
            throw new NullPointerException("Cannot remove null value");
        }
        if (isEmpty()) {
            return null;
        }
        Node<Type> current = tail.next;
        Node<Type> prev = null;
        do {
            if (current.data.equals(value)) {
                if (prev != null) {
                    prev.next = current.next;
                    if (current == tail) {
                        tail = prev;
                    }
                } else {
                    tail.next = current.next;
                }
                size--;
                return current.data;
            }
            prev = current;
            current = current.next;
        } while (current != tail.next);
        return null;
    }

    public Type removeAtIndex(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds: " + index);
        }
        if (index == 0) {
            return removeFirst();
        }
        Node<Type> current = tail.next;
        Node<Type> prev = null;
        for (int i = 0; i < index; i++) {
            prev = current;
            current = current.next;
        }
        prev.next = current.next;
        if (current == tail) {
            tail = prev;
        }
        size--;
        return current.data;
    }

    public Type get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds: " + index);
        }
        Node<Type> current = tail.next;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        return current.data;
    }

    public void set(int index, Type value) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of bounds: " + index);
        }
        if (value == null) {
            throw new NullPointerException("Cannot set null value");
        }
        Node<Type> current = tail.next;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        current.data = value;
    }

    public boolean contains(Type value) {
        if (value == null) {
            throw new NullPointerException("Cannot search for null value");
        }
        Node<Type> current = tail.next;
        do {
            if (current.data.equals(value)) {
                return true;
            }
            current = current.next;
        } while (current != tail.next);
        return false;
    }

    public void clear() {
        tail = null;
        size = 0;
    }

    public Type removeFirst() {
        if (isEmpty()) {
            throw new NoSuchElementException("List is empty");
        }
        Type removedData = tail.next.data;
        if (size == 1) {
            tail = null;
        } else {
            tail.next = tail.next.next;
        }
        size--;
        return removedData;
    }
}