// Stuart Reges
// 1/19/00
//

import java.util.*;

public class ShoppingCart {

    public static final double DISCOUNT_PERCENT = 0.9;

    public ShoppingCart() {

    }

    public void add(ItemOrder next) {

    }

    public void setDiscount(boolean discount) {

    }

    public double getTotal() {
        // This does NOT produce the correct behavior. It's only here to keep the
        // compiler happy until you replace it with working code
        return Double.MIN_VALUE;
    }
}
